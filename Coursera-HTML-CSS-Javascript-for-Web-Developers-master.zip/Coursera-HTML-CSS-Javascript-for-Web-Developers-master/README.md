# Coursera-HTML-CSS-Javascript-for-Web-Developers (by Johns Hopkins University)
This repository is created for submitting the solutions of the assignments of the course in Coursera.

Course Link: https://www.coursera.org/learn/html-css-javascript-for-web-developers

## Module #2 Coding Assignment Solution
   code url: https://github.com/kr-viku/Coursera-HTML-CSS-Javascript-for-Web-Developers/tree/master/module2-solution
   Hosted url: https://kr-viku.github.io/Coursera-HTML-CSS-Javascript-for-Web-Developers/module2-solution/

## Module #3 Coding Assignment Solution
  code url: https://github.com/kr-viku/Coursera-HTML-CSS-Javascript-for-Web-Developers/tree/master/module3-solution
  Hosted url: https://kr-viku.github.io/Coursera-HTML-CSS-Javascript-for-Web-Developers/module3-solution/

## Module #4 Coding Assignment Solution
  code url: https://github.com/kr-viku/Coursera-HTML-CSS-Javascript-for-Web-Developers/tree/master/module4-solution
  Hosted url: https://kr-viku.github.io/Coursera-HTML-CSS-Javascript-for-Web-Developers/module4-solution/

## Module #5 Coding Assignment Solution
  code url: https://github.com/kr-viku/Coursera-HTML-CSS-Javascript-for-Web-Developers/tree/master/module5-solution
  Hosted url: https://kr-viku.github.io/Coursera-HTML-CSS-Javascript-for-Web-Developers/module5-solution/
  
# Front Look

![](front_look.png)

